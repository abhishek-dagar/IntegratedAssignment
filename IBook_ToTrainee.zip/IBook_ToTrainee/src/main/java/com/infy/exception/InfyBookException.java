package com.infy.exception;

public class InfyBookException extends Exception {
	private static final long serialVersionUID = 1L;

	public InfyBookException(String message) {
		super(message);
	}
}
