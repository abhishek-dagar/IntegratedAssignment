package com.infy.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.BookDTO;
import com.infy.entity.Book;
import com.infy.exception.InfyBookException;
import com.infy.repository.BookRepository;

@Service(value = "bookService")
@Transactional
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookRepository;

	@Override
	public BookDTO getBookDetails(Integer bookId) throws InfyBookException {
		Optional<Book> book = bookRepository.findById(bookId);
		BookDTO bookDTO = new BookDTO();
		book.ifPresent((b) -> {
			bookDTO.setAuthorName(b.getAuthorName());
			bookDTO.setBookId(b.getBookId());
			bookDTO.setIsbn(b.getIsbn());
			bookDTO.setPrice(b.getPrice());
			bookDTO.setPublishedYear(b.getPublishedYear());
			bookDTO.setPublisher(b.getPublisher());
			bookDTO.setTitle(b.getTitle());

		});
		return bookDTO;
	}

	@Override
	public void addBook(BookDTO bookDTO) throws InfyBookException {
		Optional<Book> bookCheck = bookRepository.findById(bookDTO.getBookId());
		if (bookCheck.isPresent()) {
			throw new InfyBookException("Service.BOOK_ALREADY_PRESENT");
		}
		Book book = new Book();
		book.setAuthorName(bookDTO.getAuthorName());
		book.setBookId(bookDTO.getBookId());
		book.setIsbn(bookDTO.getIsbn());
		book.setPrice(bookDTO.getPrice());
		book.setPublishedYear(bookDTO.getPublishedYear());
		book.setPublisher(bookDTO.getPublisher());
		book.setTitle(bookDTO.getTitle());
		bookRepository.save(book);
	}

	@Override
	public List<BookDTO> getBookByAuthorName(String authorName) throws InfyBookException {
		List<Book> books = bookRepository.findByAuthorName(authorName);
		List<BookDTO> bookDTOs = new ArrayList<>();
		books.forEach((book) -> {
			BookDTO bookDTO = new BookDTO();
			bookDTO.setAuthorName(book.getAuthorName());
			bookDTO.setBookId(book.getBookId());
			bookDTO.setIsbn(book.getIsbn());
			bookDTO.setPrice(book.getPrice());
			bookDTO.setPublishedYear(book.getPublishedYear());
			bookDTO.setPublisher(book.getPublisher());
			bookDTO.setTitle(book.getTitle());
			bookDTOs.add(bookDTO);
		});
		return bookDTOs;
	}

	@Override
	public List<BookDTO> getBookGreaterThanEqualToPrice(Integer price) throws InfyBookException {
		List<Book> books = bookRepository.findByBookGreaterPrice(price);
		List<BookDTO> bookDTOs = new ArrayList<>();
		books.forEach((book) -> {
			BookDTO bookDTO = new BookDTO();
			bookDTO.setAuthorName(book.getAuthorName());
			bookDTO.setBookId(book.getBookId());
			bookDTO.setIsbn(book.getIsbn());
			bookDTO.setPrice(book.getPrice());
			bookDTO.setPublishedYear(book.getPublishedYear());
			bookDTO.setPublisher(book.getPublisher());
			bookDTO.setTitle(book.getTitle());
			bookDTOs.add(bookDTO);
		});
		if (bookDTOs.isEmpty()) {
			throw new InfyBookException("Service.BOOK_NOT_FOUND_IN_DATABASE");
		}
		return bookDTOs;
	}

	@Override
	public List<BookDTO> getBookLessThanPrice(Integer price) throws InfyBookException {
		List<Book> books = bookRepository.findByBookLesserPrice(price);
		List<BookDTO> bookDTOs = new ArrayList<>();
		books.forEach((book) -> {
			BookDTO bookDTO = new BookDTO();
			bookDTO.setAuthorName(book.getAuthorName());
			bookDTO.setBookId(book.getBookId());
			bookDTO.setIsbn(book.getIsbn());
			bookDTO.setPrice(book.getPrice());
			bookDTO.setPublishedYear(book.getPublishedYear());
			bookDTO.setPublisher(book.getPublisher());
			bookDTO.setTitle(book.getTitle());
			bookDTOs.add(bookDTO);
		});
		if (bookDTOs.isEmpty()) {
			throw new InfyBookException("Service.BOOK_NOT_FOUND_IN_DATABASE");
		}
		return bookDTOs;
	}

	@Override
	public List<BookDTO> bookPublishedBetweenYear(LocalDate startYear, LocalDate endYear) throws InfyBookException {
		List<Book> books = bookRepository.findByBookYear(startYear, endYear);
		List<BookDTO> bookDTOs = new ArrayList<>();
		books.forEach((book) -> {
			BookDTO bookDTO = new BookDTO();
			bookDTO.setAuthorName(book.getAuthorName());
			bookDTO.setBookId(book.getBookId());
			bookDTO.setIsbn(book.getIsbn());
			bookDTO.setPrice(book.getPrice());
			bookDTO.setPublishedYear(book.getPublishedYear());
			bookDTO.setPublisher(book.getPublisher());
			bookDTO.setTitle(book.getTitle());
			bookDTOs.add(bookDTO);
		});
		if (bookDTOs.isEmpty()) {
			throw new InfyBookException("Service.BOOK_NOT_FOUND_IN_DATABASE");
		}
		return bookDTOs;
	}

	@Override
	public List<BookDTO> bookPublishedAfterYear(LocalDate year) throws InfyBookException {
		List<Book> books = bookRepository.findByBookAfterYear(year);
		List<BookDTO> bookDTOs = new ArrayList<>();
		books.forEach((book) -> {
			BookDTO bookDTO = new BookDTO();
			bookDTO.setAuthorName(book.getAuthorName());
			bookDTO.setBookId(book.getBookId());
			bookDTO.setIsbn(book.getIsbn());
			bookDTO.setPrice(book.getPrice());
			bookDTO.setPublishedYear(book.getPublishedYear());
			bookDTO.setPublisher(book.getPublisher());
			bookDTO.setTitle(book.getTitle());
			bookDTOs.add(bookDTO);
		});
		if (bookDTOs.isEmpty()) {
			throw new InfyBookException("Service.BOOK_NOT_FOUND_IN_DATABASE");
		}
		return bookDTOs;
	}

	@Override
	public List<BookDTO> getBookByAuthorNameAndPublisher(String authorName, String publisher) throws InfyBookException {
		List<Book> books = bookRepository.findBookByAuthorNameAndPublisher(authorName, publisher);
		List<BookDTO> bookDTOs = new ArrayList<>();
		books.forEach((book) -> {
			BookDTO bookDTO = new BookDTO();
			bookDTO.setAuthorName(book.getAuthorName());
			bookDTO.setBookId(book.getBookId());
			bookDTO.setIsbn(book.getIsbn());
			bookDTO.setPrice(book.getPrice());
			bookDTO.setPublishedYear(book.getPublishedYear());
			bookDTO.setPublisher(book.getPublisher());
			bookDTO.setTitle(book.getTitle());
			bookDTOs.add(bookDTO);
		});
		if (bookDTOs.isEmpty()) {
			throw new InfyBookException("Service.BOOK_NOT_FOUND_IN_DATABASE");
		}
		return bookDTOs;
	}

	@Override
	public void updateBookPrice(Integer bookId, Integer price) throws InfyBookException {
		Optional<Book> optional = bookRepository.findById(bookId);
		Book book = optional.orElseThrow(() -> new InfyBookException("Service.BOOK_NOT_FOUND_IN_DATABASE"));
		book.setPrice(price);
	}

	@Override
	public void deleteBook(Integer bookId) throws InfyBookException {
		Optional<Book> optional = bookRepository.findById(bookId);
		optional.orElseThrow(() -> new InfyBookException("Service.BOOK_NOT_FOUND_IN_DATABASE"));
		bookRepository.deleteById(bookId);
	}

}
