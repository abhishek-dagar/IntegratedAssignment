package com.infy.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infy.entity.Book;


public interface BookRepository extends CrudRepository<Book, Integer> {
    List<Book> findByAuthorName(String authorName);
    @Query("select b from Book b where b.price>=:price")
    List<Book> findByBookGreaterPrice(@Param("price") Integer price);
    @Query("select b from Book b where b.price<:price")
    List<Book> findByBookLesserPrice(@Param("price") Integer price);
    @Query("select b from Book b where b.publishedYear BETWEEN :startYear and :endYear")
    List<Book> findByBookYear(@Param("startYear") LocalDate startYear,@Param("endYear") LocalDate endYear);
    @Query("select b from Book b where b.publishedYear > :year")
    List<Book> findByBookAfterYear(@Param("year") LocalDate year);
    @Query("select b from Book b where b.publisher=:publisher and b.authorName=:authorName")
    List<Book> findBookByAuthorNameAndPublisher(@Param("authorName") String authorName,@Param("publisher") String publisher);
}