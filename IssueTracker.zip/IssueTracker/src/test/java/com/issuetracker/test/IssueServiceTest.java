package com.issuetracker.test;

import java.time.LocalDate;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueStatus;
import com.issuetracker.model.Unit;
import com.issuetracker.service.IssueService;
import com.issuetracker.service.IssueServiceImpl;

public class IssueServiceTest
{
    private IssueService issueService = new IssueServiceImpl();
    Configurations configurations = new Configurations();

    @Test
    public void reportAnIssueValidTest() throws IssueTrackerException, ConfigurationException
    {
        Issue issue = new Issue("MTI-I-013-HS", "Third menu is missing",
                                Unit.ADMINISTRATION,
                                LocalDate.now().minusDays(11), null, null,
                                IssueStatus.IN_PROGRESS);
        String issueMessage = issueService.reportAnIssue(issue);
        Assertions.assertEquals("MTI-I-013-HS", issueMessage);
    }

    @Test
    public void reportAnIssueInvalidReportedDateTest() throws ConfigurationException
    {
        PropertiesConfiguration propertiesConfiguration = configurations.properties("configuration.properties");
        Issue issue = new Issue("MTI-I-013-HS", "Third menu is missing",
                                Unit.ADMINISTRATION,
                                LocalDate.now().plusDays(5), null, null,
                                IssueStatus.IN_PROGRESS);
        IssueTrackerException issueTrackerException = Assertions.assertThrows(IssueTrackerException.class,
                                                                              () -> issueService.reportAnIssue(issue));
        Assertions.assertEquals(propertiesConfiguration.getProperty(issueTrackerException.getMessage()),
                                propertiesConfiguration.getProperty("Validator.INVALID_REPORTED_DATE"));
    }

    @Test
    public void reportAnIssueInvalidStatusTest() throws ConfigurationException
    {
        PropertiesConfiguration propertiesConfiguration = configurations.properties("configuration.properties");
        Issue issue = new Issue("MTI-I-013-HS", "Third menu is missing",
                                Unit.ADMINISTRATION,
                                LocalDate.now().minusDays(11), null, null,
                                IssueStatus.CLOSED);
        IssueTrackerException issueTrackerException = Assertions.assertThrows(IssueTrackerException.class,
                                                                              () -> issueService.reportAnIssue(issue));
        Assertions.assertEquals(propertiesConfiguration.getProperty(issueTrackerException.getMessage()),
                                propertiesConfiguration.getProperty("Validator.INVALID_STATUS"));

    }

    @Test
    public void reportAnIssueDuplicateIssueIdTest() throws ConfigurationException
    {
        PropertiesConfiguration propertiesConfiguration = configurations.properties("configuration.properties");
        Issue issue = new Issue("MTI-I-001-MS", "Third menu is missing",
                                Unit.ADMINISTRATION,
                                LocalDate.now().minusDays(11), null, null,
                                IssueStatus.IN_PROGRESS);
        IssueTrackerException issueTrackerException = Assertions.assertThrows(IssueTrackerException.class,
                                                                              () -> issueService.reportAnIssue(issue));
        System.out.println(issueTrackerException.getMessage());
        Assertions.assertEquals(propertiesConfiguration.getProperty("IssueService.DUPLICATE_ISSUE_ID"),
                                propertiesConfiguration.getProperty(issueTrackerException.getMessage()));
    }
}