package com.issuetracker.model;

public enum IssueStatus
{
    OPEN,
    IN_PROGRESS,
    CLOSED,
    RESOLVED,
    RECALLED
}