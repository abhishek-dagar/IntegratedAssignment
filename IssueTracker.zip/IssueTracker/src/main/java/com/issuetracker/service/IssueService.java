package com.issuetracker.service;

import java.util.List;
import java.util.Map;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueReport;
import com.issuetracker.model.IssueStatus;

public interface IssueService
{
    /**
     * Reports a new issue by validating its details, fetch an assignee and
     * persist the issue in the issueList
     * 
     * @param issue
     *        The new issue to be reported
     * 
     * @return The issue id
     */
    public abstract String reportAnIssue(Issue issue) throws IssueTrackerException;

    /**
     * Updates the status of the given issue with the given status
     * 
     * @param issueId
     *        The issue id
     * 
     * @param status
     *        The new status
     * 
     * @return The result of the status update
     */
    public abstract Boolean updateStatus(String issueId,
					 IssueStatus status) throws IssueTrackerException;

    /**
     * Generates a report of issues based on the filter criteria
     * 
     * @param filterCriteria
     *        A map where its <i>key</i> denotes an attribute of the issue
     *        object and <i>value</i> contains the filter value
     * 
     * @return The list of filtered issue objects
     */
    public abstract List<IssueReport> showIssues(Map<Character, Object> filterCriteria) throws IssueTrackerException;

    /**
     * Deletes the issue object which are resolved or closed, at least 14 days
     * ago
     * 
     * @return The list of issue objects which had been deleted
     */
    public abstract List<Issue> deleteIssues() throws IssueTrackerException;
}