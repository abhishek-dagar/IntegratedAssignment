package com.issuetracker.service;

import java.util.ArrayList;
import java.util.List;

import com.issuetracker.dao.AssigneeDAO;
import com.issuetracker.dao.AssigneeDAOImpl;
import com.issuetracker.model.Assignee;
import com.issuetracker.model.Unit;

public class AssigneeServiceImpl implements AssigneeService
{
    private AssigneeDAO assigneeDAO = new AssigneeDAOImpl();

    @Override
    public List<Assignee> fetchAssignee(Unit unit)
    {
        // Your Code Goes Here
        List<Assignee> filteredAssignees = new ArrayList<>();
        List<Assignee> assignees = assigneeDAO.fetchAssignees(unit);
        for (Assignee assignee : assignees)
        {
            if (assignee.getNumberOfIssuesActive() < 3)
            {
                filteredAssignees.add(assignee);
            }
        }
        return filteredAssignees;
    }

    @Override
    public void updateActiveIssueCount(String assigneeEmail,
                                       Character operation)
    {
        // Your Code Goes Here
        Assignee assignee = assigneeDAO.getAssigneeByEmail(assigneeEmail);
        switch (operation)
        {
            case 'I':
                assignee.setNumberOfIssuesActive(assignee.getNumberOfIssuesActive()
                                                 + 1);
                break;
            case 'D':
                assignee.setNumberOfIssuesActive(assignee.getNumberOfIssuesActive()
                                                 - 1);
                break;
        }
    }
}