package com.issuetracker.service;

import java.time.LocalDate;
import java.util.*;
import com.issuetracker.dao.*;
import com.issuetracker.model.*;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.validator.Validator;

public class IssueServiceImpl implements IssueService
{
    private AssigneeService assigneeService = new AssigneeServiceImpl();

    private IssueDAO issueDAO = new IssueDAOImpl();

    private Validator validator = new Validator();

    @Override
    public String reportAnIssue(Issue issue) throws IssueTrackerException
    {
        // Your Code Goes Here
        validator.validate(issue);
        List<Assignee> assignees = assigneeService.fetchAssignee(issue.getIssueUnit());
        if (assignees.size() > 0)
        {
            issue.setAssigneeEmail(assignees.get(0).getAssigneeEmail());
            assigneeService.updateActiveIssueCount(assignees.get(0)
                                                            .getAssigneeEmail(),
                                                   'I');
        }
        String issueId = issueDAO.reportAnIssue(issue);
        if (issueId == null)
            throw new IssueTrackerException("IssueService.DUPLICATE_ISSUE_ID");
        return issueId;
    }

    @Override
    public Boolean updateStatus(String issueId,
                                IssueStatus status) throws IssueTrackerException
    {
        // Your Code Goes Here
        Issue issueById = issueDAO.getIssueById(issueId);
        if (issueById == null)
        {
            throw new IssueTrackerException("An issue with the given ID is not found!");
        }
        if (status == issueById.getStatus())
        {
            throw new IssueTrackerException("There is no change in the issue status!");
        }
        if (status == IssueStatus.RECALLED
            && issueById.getStatus() == IssueStatus.OPEN)
        {
            throw new IssueTrackerException("The current issue status is incompatible for recall!");
        }
        issueDAO.updateStatus(issueById, status);
        if (issueById.getStatus() != IssueStatus.OPEN
            || issueById.getStatus() == IssueStatus.IN_PROGRESS)
        {
            assigneeService.updateActiveIssueCount(issueById.getAssigneeEmail(),
                                                   'D');
        }
        return true;
    }

    @Override
    public List<IssueReport> showIssues(Map<Character, Object> filterCriteria) throws IssueTrackerException
    {
        // Your Code Goes Here
        List<IssueReport> issueReports = new ArrayList<>();
        List<Issue> getIssueList = issueDAO.getIssueList();
        if (filterCriteria.get('A') != null)
        {
            for (Issue issue : getIssueList)
            {
                if (issue.getAssigneeEmail() == filterCriteria.get('A'))
                {
                    IssueReport issueReport = new IssueReport(issue.getIssueId(),
                                                              issue.getIssueDescription(),
                                                              issue.getAssigneeEmail(),
                                                              issue.getStatus());
                    issueReports.add(issueReport);
                }
            }
        }
        if (filterCriteria.get('S') != null)
        {
            for (Issue issue : getIssueList)
            {
                if (issue.getStatus() == filterCriteria.get('S'))
                {
                    IssueReport issueReport = new IssueReport(issue.getIssueId(),
                                                              issue.getIssueDescription(),
                                                              issue.getAssigneeEmail(),
                                                              issue.getStatus());
                    issueReports.add(issueReport);
                }
            }
        }
        return issueReports;
    }

    @Override
    public List<Issue> deleteIssues() throws IssueTrackerException
    {
        // Your Code Goes Here
        List<Issue> issuesList = issueDAO.getIssueList();
        List<Issue> newIssuesList = new ArrayList<>();
        List<Issue> deletedIssuesList = new ArrayList<>();
        for (Issue issue : issuesList)
        {
            if (issue.getUpdatedOn() != null
                && (issue.getStatus() == IssueStatus.RESOLVED
                    || issue.getStatus() == IssueStatus.CLOSED)
                && issue.getUpdatedOn().isBefore(LocalDate.now().minusDays(13)))
            {
                deletedIssuesList.add(issue);
            }
            else
            {
                newIssuesList.add(issue);
            }
        }
        issueDAO.setIssueList(newIssuesList);
        return deletedIssuesList;
    }
}