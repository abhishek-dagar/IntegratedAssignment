package com.issuetracker.service;

import java.time.LocalDate;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueStatus;
import com.issuetracker.model.Unit;

public class ReportThread implements Runnable
{

    private IssueService issueService = new IssueServiceImpl();
    private static PropertiesConfiguration propertiesConfiguration;

    private static final Log LOG = LogFactory.getLog(ReportThread.class);

    static
    {
        try
        {
            propertiesConfiguration = new Configurations().properties("configuration.properties");
        }
        catch (ConfigurationException e)
        {
            // TODO Auto-generated catch block
            LOG.error(e.getMessage());
        }
    }

    public ReportThread(IssueService issueService)
    {
        this.issueService = issueService;
    }

    @Override
    public void run()
    {
        // TODO Auto-generated method stub
        LOG.info("Mont Trance Inc. | Reporting An Issue");
        // Uncomment the below code

        Issue issue = new Issue("MTI-I-013-LS", "Booting up time is very high",
                                Unit.ADMINISTRATION,
                                LocalDate.now().minusDays(1), null, null,
                                IssueStatus.CLOSED);

        try
        {
            String issueId = issueService.reportAnIssue(issue);

            LOG.info(propertiesConfiguration.getProperty("IssueTester.REPORT_ISSUE_SUCCESS")
                     + " " + issueId);
        }
        catch (IssueTrackerException issueTrackerException)
        {
            String exceptionMessage = issueTrackerException.getMessage();
            if (exceptionMessage == null)
            {
                exceptionMessage = "IssueTester.GENERAL_EXCEPTION";
            }

            String errorMessage = (String) propertiesConfiguration.getProperty(exceptionMessage);
            if (errorMessage == null)
            {
                errorMessage = (String) propertiesConfiguration.getProperty("IssueTester.GENERAL_EXCEPTION");
            }

            LOG.info(String.format("ERROR: %s", errorMessage));
        }
    }

}
