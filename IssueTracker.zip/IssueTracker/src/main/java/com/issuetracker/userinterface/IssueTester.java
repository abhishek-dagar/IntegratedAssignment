package com.issuetracker.userinterface;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.configuration2.ex.ConfigurationException;

import com.issuetracker.service.IssueService;
import com.issuetracker.service.IssueServiceImpl;
import com.issuetracker.service.ReportThread;
import com.issuetracker.service.ShowThread;
import com.issuetracker.service.UpdateThread;

public class IssueTester
{
    private static IssueService issueService;

    public static void main(String[] args) throws ConfigurationException
    {
        issueService = new IssueServiceImpl();
        // Implement ExecutorService to invoke all the functionalities
        ExecutorService executorService = Executors.newFixedThreadPool(1);

        executorService.execute(new ReportThread(issueService));
//        executorService.execute(new UpdateThread(issueService));
//        executorService.execute(new ShowThread(issueService));

        // Shutdown ExecutorService
        executorService.shutdown();

    }
}
