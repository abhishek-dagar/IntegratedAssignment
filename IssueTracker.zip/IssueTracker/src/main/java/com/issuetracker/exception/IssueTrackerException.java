package com.issuetracker.exception;

public class IssueTrackerException extends Exception
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public IssueTrackerException(String message)
    {
	super(message);
    }
}