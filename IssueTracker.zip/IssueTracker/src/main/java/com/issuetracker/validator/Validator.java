package com.issuetracker.validator;

import java.time.LocalDate;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueStatus;

public class Validator
{
    public void validate(Issue issue) throws IssueTrackerException
    {
        if (!isValidIssueId(issue.getIssueId()))
        {
            throw new IssueTrackerException("Validator.INVALID_ISSUE_ID");
        }
        if (!isValidIssueDescription(issue.getIssueDescription()))
        {
            throw new IssueTrackerException("Validator.INVALID_ISSUE_DESCRIPTION");
        }
        if (!isValidReportedOn(issue.getReportedOn()))
        {
            throw new IssueTrackerException("Validator.INVALID_REPORTED_DATE");
        }
        if (!isValidStatus(issue.getStatus()))
        {
            throw new IssueTrackerException("Validator.INVALID_STATUS");
        }
    }

    public Boolean isValidIssueId(String issueId)
    {
        if (issueId == null || issueId == "")
            return false;

        return issueId.matches("MTI-I-((?!000)[0-9]{3})-(HS|MS|LS)");

    }

    public Boolean isValidIssueDescription(String issueDescription)
    {
        if (issueDescription == null || issueDescription == ""
            || issueDescription.split(" ").length == 0)
            return false;
        return issueDescription.matches("([^\\s])([\\w\\s]{0,50})([^\\s])");
    }

    public Boolean isValidReportedOn(LocalDate reportedOn)
    {
        return reportedOn.isBefore(LocalDate.now());
    }

    public Boolean isValidStatus(IssueStatus status)
    {
        return status == IssueStatus.OPEN || status == IssueStatus.IN_PROGRESS;
    }
}