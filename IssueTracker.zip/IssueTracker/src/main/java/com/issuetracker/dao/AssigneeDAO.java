package com.issuetracker.dao;

import java.util.List;

import com.issuetracker.model.Assignee;
import com.issuetracker.model.Unit;

public interface AssigneeDAO
{
    /**
     * Fetches the assignees list for the given unit
     * 
     * @param unit
     *        The assignee unit
     * 
     * @return The list of assignee objects fetched
     */
    public abstract List<Assignee> fetchAssignees(Unit unit);

    /**
     * Fetches the assignee by the given email of the assignee
     * 
     * @param
     * assigneeEmail
     *        The assignee email id
     * 
     * @return The fetched assignee object
     */
    public abstract Assignee getAssigneeByEmail(String assigneeEmail);
}