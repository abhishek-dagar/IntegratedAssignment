package com.infy.test;

import java.util.*;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceRequest;
import com.infy.service.MobileService;
import com.infy.service.MobileServiceImpl;

public class MobileServiceTest {

	private MobileService mobileService = new MobileServiceImpl();

	@Test
	public void registerRequestInvalidBrandTest() throws ConfigurationException, MobileServiceException {
		// your code goes here
		Configurations configurations = new Configurations();
		PropertiesConfiguration config = configurations.properties("configuration.properties");
		ServiceRequest serviceRequest = new ServiceRequest("abc", Arrays.asList("Battery"), 9876543210L, "Chap",
				3214567890123456L);
		MobileServiceException mobileServiceException = Assertions.assertThrows(MobileServiceException.class,
				() -> mobileService.registerRequest(serviceRequest));
		Assertions.assertEquals(config.getProperty(mobileServiceException.getMessage()),
				config.getProperty("Validator.INVALID_BRAND"));

	}

	@Test
	public void registerRequestInvalidContactNumberTest() throws ConfigurationException, MobileServiceException {
		// your code goes here
		Configurations configurations = new Configurations();
		PropertiesConfiguration config = configurations.properties("configuration.properties");
		ServiceRequest serviceRequest = new ServiceRequest("Abc", Arrays.asList("Battery"), 987654L, "Chap",
				3214567890123456L);
		MobileServiceException mobileServiceException = Assertions.assertThrows(MobileServiceException.class,
				() -> mobileService.registerRequest(serviceRequest));
		Assertions.assertEquals(config.getProperty(mobileServiceException.getMessage()),
				config.getProperty("Validator.INVALID_CONTACT_NUMBER"));
	}

	@Test
	public void registerRequestInvalidIssuesTest() throws ConfigurationException {
		// your code goes here
		Configurations configurations = new Configurations();
		PropertiesConfiguration config = configurations.properties("configuration.properties");
		ServiceRequest serviceRequest = new ServiceRequest("Abc", Arrays.asList("broken screen"), 9876543210L, "Chap",
				3214567890123456L);
		MobileServiceException mobileServiceException = Assertions.assertThrows(MobileServiceException.class,
				() -> mobileService.registerRequest(serviceRequest));
		Assertions.assertEquals(config.getProperty(mobileServiceException.getMessage()),
				config.getProperty("Service.INVALID_ISSUES"));
	}

}
