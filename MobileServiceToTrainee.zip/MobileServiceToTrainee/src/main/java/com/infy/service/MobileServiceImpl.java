package com.infy.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.infy.dao.MobileServiceDAO;
import com.infy.dao.MobileServiceDAOImpl;
import com.infy.exception.MobileServiceException;
import com.infy.model.ServiceReport;
import com.infy.model.ServiceRequest;
import com.infy.model.Status;
import com.infy.validator.Validator;

public class MobileServiceImpl implements MobileService{
	
	private MobileServiceDAO dao=new MobileServiceDAOImpl();
	
	private Validator validator=new Validator();
	@Override
	public ServiceRequest registerRequest(ServiceRequest service) throws MobileServiceException {
		validator.validate(service);
		Float estimateCost = calculateEstimateCost(service.getIssues());
		if (estimateCost <= 0)
			throw new MobileServiceException("Service.INVALID_ISSUES");
		service.setServiceFee(estimateCost);
		service.setStatus(Status.ACCEPTED);
		service.setTimeOfRequest(LocalDateTime.now());
		return dao.registerRequest(service);
	}

	@Override
	public Float calculateEstimateCost(List<String> issues) throws MobileServiceException {
		Float estimateCost = 0F;
		for (String stringIssues : issues) {
			switch (stringIssues.toLowerCase()) {
				case "battery":
					estimateCost += 10;
					break;
				case "camera":
					estimateCost += 5;
					break;
				case "screen":
					estimateCost += 15;
					break;
			}
		}
		return estimateCost;
	}

	@Override
	public List<ServiceReport> getServices(Status status) throws MobileServiceException {
		List<ServiceReport> services = new ArrayList<>();
		List<ServiceRequest> serviceRequests = dao.getServices();
		for (ServiceRequest serviceRequest : serviceRequests) {
			if (serviceRequest.getStatus() == status) {
				ServiceReport serviceReport = new ServiceReport(serviceRequest.getServiceId(),
						serviceRequest.getBrand(),
						serviceRequest.getIssues(), serviceRequest.getServiceFee());
				services.add(serviceReport);
			}
		}
		if(services.isEmpty()){
			throw new MobileServiceException("Service.NO_RECORDS_FOUND");
		}
		return services;
	}

}
