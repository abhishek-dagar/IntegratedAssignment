package com.infy.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.dto.MovieDTO;
import com.infy.entity.Movie;

@Repository(value = "movieRepository")
public class MovieRepositoryImpl implements MovieRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public MovieDTO getMovieByName(String movieName) {
		String qString = "select m from movie m where m.movieName = ?1";
		Query query = entityManager.createQuery(qString);
		query.setParameter(1, movieName);

		Movie movie = (Movie) query.getSingleResult();

		MovieDTO movieDTO = new MovieDTO();
		movieDTO.setMovieId(movie.getMovieId());
		movieDTO.setMovieName(movie.getMovieName());
		movieDTO.setDirectorName(movie.getDirectorName());
		movieDTO.setImdbRating(movie.getImdbRating());
		movieDTO.setYear(movie.getYear());
		return movieDTO;
	}

	@Override
	public List<MovieDTO> getMoviesByImdbRating(Double fromRating, Double toRating) {
		String qString = "select m from movie m where m.imdbRating between ?1 and ?2";
		Query query = entityManager.createQuery(qString, Movie.class);
		query.setParameter(1, Float.valueOf(fromRating.toString()));
		query.setParameter(2, Float.valueOf(toRating.toString()));
		List<Movie> movies = query.getResultList();
		List<MovieDTO> movieDTOs = new ArrayList<>();
		for (Movie movie : movies) {
			MovieDTO movieDTO = new MovieDTO();
			movieDTO.setMovieId(movie.getMovieId());
			movieDTO.setMovieName(movie.getMovieName());
			movieDTO.setDirectorName(movie.getDirectorName());
			movieDTO.setImdbRating(movie.getImdbRating());
			movieDTO.setYear(movie.getYear());
			movieDTOs.add(movieDTO);
		}
		return movieDTOs;
	}

	@Override
	public List<Object[]> getMoviesNameAndYear(String directorName) {
		String qString = "select m.movieName, m.year from movie m where m.directorName= ?1";
		Query query = entityManager.createQuery(qString);
		query.setParameter(1, directorName);
		List<Object[]> movies = query.getResultList();
		return movies;
	}

}
