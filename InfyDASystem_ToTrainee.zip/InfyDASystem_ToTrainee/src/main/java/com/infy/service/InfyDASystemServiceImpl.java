package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.TraineeDTO;
import com.infy.exception.InfyDASystemException;
import com.infy.repository.InfyDASystemRepositoryImpl;


@Service
public class InfyDASystemServiceImpl implements InfyDASystemService {

	@Autowired
	private InfyDASystemRepositoryImpl infyDASystemRepositoryImpl;

	public TraineeDTO getAllocationDetails(Integer traineeId) throws InfyDASystemException {
		TraineeDTO traineeDTO = infyDASystemRepositoryImpl.getAllocationDetails(traineeId);
		if(traineeDTO == null){
			throw new InfyDASystemException("Service.NO_DETAILS_FOUND");
		}
		return traineeDTO;
	}

	public Integer addNewTrainee(TraineeDTO trainee) throws InfyDASystemException {
		return infyDASystemRepositoryImpl.addNewTrainee(trainee);
	}

	
}
