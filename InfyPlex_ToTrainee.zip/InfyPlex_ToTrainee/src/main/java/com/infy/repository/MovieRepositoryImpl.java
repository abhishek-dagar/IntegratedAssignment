package com.infy.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.dto.MovieDTO;
import com.infy.entity.Movie;

@Repository(value = "movieRepository")
public class MovieRepositoryImpl implements MovieRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<MovieDTO> getMovieByRating(Double fromRating) {
		String queryString = "select m from Movie m where m.imdbRating>=:fromRating";
		Query query = entityManager.createQuery(queryString);
		query.setParameter("fromRating", Float.valueOf(fromRating.toString()));
		List<Movie> movies = query.getResultList();
		List<MovieDTO> movieDTOs = new ArrayList<>();
		movies.forEach((movie) -> {
			MovieDTO movieDTO = new MovieDTO();
			movieDTO.setDirectorName(movie.getDirectorName());
			movieDTO.setImdbRating(movie.getImdbRating());
			movieDTO.setMovieId(movie.getMovieId());
			movieDTO.setMovieName(movie.getMovieName());
			movieDTO.setYear(movie.getYear());
			movieDTOs.add(movieDTO);
		});
		return movieDTOs;
	}

	@Override
	public List<MovieDTO> getHighestRatedMovie(String directorName) {
		String queryString = "select m from Movie m where m.directorName=:directorName and m.imdbRating=(select max(m.imdbRating) from Movie m where m.directorName=:directorName)";
		Query query = entityManager.createQuery(queryString);
		query.setParameter("directorName", directorName);
		List<Movie> movies = query.getResultList();
		List<MovieDTO> movieDTOs = new ArrayList<>();
		movies.forEach((movie) -> {
			MovieDTO movieDTO = new MovieDTO();
			movieDTO.setDirectorName(movie.getDirectorName());
			movieDTO.setImdbRating(movie.getImdbRating());
			movieDTO.setMovieId(movie.getMovieId());
			movieDTO.setMovieName(movie.getMovieName());
			movieDTO.setYear(movie.getYear());
			movieDTOs.add(movieDTO);
		});
		return movieDTOs;
	}

	@Override
	public Float getAverageDirectorRating(String directorName) {
		String queryString = "select AVG(m.imdbRating) from Movie m where m.directorName=:directorName";
		Query query = entityManager.createQuery(queryString);
		query.setParameter("directorName", directorName);
		Double averageDirectorRating = (Double) query.getSingleResult();
		return Float.valueOf(averageDirectorRating.toString());
	}

	@Override
	public Long getNumberOfMoviesReleased(Integer fromYear, Integer toYear) {
		String queryString = "select COUNT(m) from Movie m where m.year BETWEEN :fromYear and :toYear";
		Query query = entityManager.createQuery(queryString);
		query.setParameter("fromYear", fromYear);
		query.setParameter("toYear", toYear);
		return (Long) query.getSingleResult();
		// return null;
	}

}
