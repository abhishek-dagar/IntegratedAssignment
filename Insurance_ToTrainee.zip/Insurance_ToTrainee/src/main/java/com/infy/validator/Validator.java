package com.infy.validator;

import java.time.LocalDate;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;

public class Validator {

	public static void validate(PolicyDTO policy) throws InsuranceException {
		if (!validatePolicyName(policy.getPolicyName())) {
			throw new InsuranceException("Validator.INVALID_POLICY_NAME");
		}
		if (!validatePolicyType(policy.getPolicyType())) {
			throw new InsuranceException("Validator.INVALID_POLICY_TYPE");
		}
		if (!validatePremium(policy.getPremium())) {
			throw new InsuranceException("Validator.INVALID_PREMIUM");
		}
		if (!validateTenure(policy.getTenureInMonths())) {
			throw new InsuranceException("Validator.INVALID_TENURE");
		}
		if (!validateDateOfBirth(policy.getDateOfBirth())) {
			throw new InsuranceException("Validator.INVALID_DOB");
		}
		if (!validatePolicyNumber(policy.getPolicyNumber(), policy.getPolicyType())) {
			throw new InsuranceException("Validator.INVALID_POLICY_NUMBER");
		}
		if (!validatePolicyHolderName(policy.getPolicyHolderName())) {
			throw new InsuranceException("Validator.INVALID_HOLDER_NAME");
		}
	}

	public static Boolean validatePolicyName(String policyName) {
		return policyName.matches("[a-zA-Z]+");

	}

	public static Boolean validatePolicyType(String policyType) {
		return policyType.matches("Term Life Insurance|Whole Life Policy|Endowment Plans");

	}

	public static Boolean validatePremium(Double premium) {
		return premium > 100;

	}

	public static Boolean validateTenure(Integer tenureInMonths) {

		return tenureInMonths > 24;

	}

	public static Boolean validateDateOfBirth(LocalDate dateOfBirth) {

		return dateOfBirth.isBefore(LocalDate.now());

	}

	public static Boolean validatePolicyNumber(String policyNumber, String policyType) {
		return policyType.equals("Term Life Insurance") ? policyNumber.matches("TL-[0-9]{6}")
				: policyType.equals("Whole Life Policy") ? policyNumber.matches("WL-[0-9]{6}")
						: policyType.equals("EndowMent Plans") ? policyNumber.matches("EP-[0-9]{6}") : false;

	}

	public static Boolean validatePolicyHolderName(String policyHolderName) {

		return policyHolderName.matches("[^\s](?!.* .* )[a-zA-Z\s]+[^\s]");

	}
}
