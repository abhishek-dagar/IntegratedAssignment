package com.infy.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;
import com.infy.model.PolicyReportDTO;
import com.infy.repository.InsuranceRepositoryImpl;
import com.infy.validator.Validator;

@Service
public class InsuranceServiceImpl implements InsuranceService {

	@Autowired
	private InsuranceRepositoryImpl insuranceRepositoryImpl;

	public String buyPolicy(PolicyDTO policy) throws InsuranceException {
		Validator.validate(policy);
		String policyNumber = insuranceRepositoryImpl.buyPolicy(policy);

		return policyNumber;
	}

	public Long calculateAge(LocalDate dateOfBirth) throws InsuranceException {
		return ChronoUnit.MONTHS.between(dateOfBirth, LocalDate.now());
	}

	public List<PolicyReportDTO> getReport(String policyType) throws InsuranceException {
		List<PolicyDTO> policyDTOs = insuranceRepositoryImpl.getAllPolicyDetails();
		List<PolicyDTO> policyDTOsFilter = policyDTOs.stream()
				.filter((policyDTO) -> policyDTO.getPolicyType().equals(policyType)).collect(Collectors.toList());
		if (policyDTOsFilter.isEmpty()) {
			throw new InsuranceException("Service.NO_RECORD");
		}
		List<PolicyReportDTO> reportList = new ArrayList<>();
		policyDTOsFilter.forEach((policyDTO) -> {
			PolicyReportDTO policyReportDTO = new PolicyReportDTO();
			policyReportDTO.setPolicyNumber(policyDTO.getPolicyNumber());
			policyReportDTO.setPolicyHolderName(policyDTO.getPolicyHolderName());
			policyReportDTO.setTenureInMonths(policyDTO.getTenureInMonths());
			try {
				policyReportDTO.setPolicyHolderAge(Double.valueOf(calculateAge(policyDTO.getDateOfBirth())));
			} catch (InsuranceException e) {
				e.printStackTrace();
			}
			reportList.add(policyReportDTO);
		});
		return reportList;
	}

}
